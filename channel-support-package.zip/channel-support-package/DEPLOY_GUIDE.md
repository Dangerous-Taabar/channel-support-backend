# Channel Support Center — Complete Hosting Guide

Follow these steps in order. Total time: ~30-40 minutes, everything free.

---

## PART 1 — Telegram Bot Setup (needed for real admin verification)

1. Open Telegram, search **@BotFather**, start a chat.
2. Send `/newbot`, give it a name (e.g. `Channel Support Bot`) and a username ending in `bot` (e.g. `channelsupport_bot`).
3. BotFather will give you a **token** like `123456789:AAExxxxxxxxxxxxxxxxxxxxxxxxxxx` — copy and save it. This is your `TELEGRAM_BOT_TOKEN`.
4. Go to your channel/group → **Manage** → **Administrators** → **Add Admin** → add your bot. It doesn't need special permissions, just needs to be a member/admin so it can read member statuses.
5. Get your **Chat ID**:
   - If it's a public channel/group with a username: use `@yourchannelusername` directly as `TELEGRAM_CHAT_ID`.
   - If it's private: forward any message from the channel/group to **@userinfobot** or **@RawDataBot** — it'll show a `chat.id` like `-1001234567890`. Use that (including the `-100` prefix) as `TELEGRAM_CHAT_ID`.

---

## PART 2 — GPLinks Setup (shortlink verification)

1. Sign up at [gplinks.in](https://gplinks.in) (or your preferred API-verified shortlink provider).
2. Go to your dashboard → **API** section → copy your **API key**. This is `GPLINKS_API_KEY`.
3. Note the API base URL shown in their docs — usually `https://gplinks.in/api` (this is `GPLINKS_API_URL`).

---

## PART 3 — Deploy the Backend (Render, free tier)

1. Create a GitHub account if you don't have one, and a new **public or private repo** (e.g. `channel-support-backend`).
2. Upload the `support-backend` folder's contents (`server.js`, `package.json`, `.env.example`, `README.md`) to that repo — easiest via GitHub's web "Add file → Upload files".
3. Go to [render.com](https://render.com) → sign up/login (can use GitHub login) → **New +** → **Web Service**.
4. Connect the repo you just created.
5. Settings:
   - **Build Command:** `npm install`
   - **Start Command:** `npm start`
   - **Instance Type:** Free
6. Before deploying, click **Advanced → Add Environment Variable** and add all of these (values from Parts 1 & 2):

   | Key | Value |
   |---|---|
   | `SESSION_SECRET` | any long random string, e.g. `xk29Ldp83jZQmw...` |
   | `PUBLIC_BASE_URL` | leave blank for now, you'll fill this after step 7 |
   | `ALLOWED_ORIGINS` | `*` for now (tighten later to your frontend URL) |
   | `GPLINKS_API_KEY` | from Part 2 |
   | `GPLINKS_API_URL` | `https://gplinks.in/api` |
   | `TELEGRAM_BOT_TOKEN` | from Part 1 |
   | `TELEGRAM_CHAT_ID` | from Part 1 |
   | `MIN_DWELL_SECONDS` | `15` |

7. Click **Create Web Service**. Wait for it to build and deploy (2-3 min). Render will give you a live URL like `https://channel-support-backend.onrender.com`.
8. Go back to **Environment**, edit `PUBLIC_BASE_URL` to that exact URL, save — this triggers a redeploy.

Your backend is now live. Test it by visiting the URL in a browser — you should see "Channel Support backend is running."

> Free Render services sleep after 15 min of no traffic and take ~30s to wake up on the next request — fine for a fan project, upgrade to a paid instance later if you want it always-instant.

---

## PART 4 — Deploy the Frontend (Netlify, free, drag-and-drop)

1. Go to [netlify.com](https://netlify.com) → sign up/login.
2. On the dashboard, find **"Deploys"** → drag and drop your `support-page.html` file directly onto the page (Netlify's "Deploy manually" drop zone). Rename it to `index.html` before uploading so it loads at the root URL.
3. Netlify gives you a live URL like `https://random-name-123.netlify.app`. You can rename the site (Site settings → Change site name) to something like `channel-support.netlify.app`.

*(GitHub Pages, Vercel, or Cloudflare Pages all work the same way if you prefer those.)*

---

## PART 5 — Connect Frontend ↔ Backend

1. Open your `support-page.html` (the copy you're about to upload), find this line near the top of the `<script>`:
   ```js
   const API_BASE_URL = "";
   ```
   Change it to your Render URL from Part 3:
   ```js
   const API_BASE_URL = "https://channel-support-backend.onrender.com";
   ```
2. Re-upload this updated file to Netlify (drag-and-drop again over the existing site — it redeploys instantly).
3. Go back to Render → Environment → set `ALLOWED_ORIGINS` to your real Netlify URL (e.g. `https://channel-support.netlify.app`) instead of `*`, save (redeploys automatically). This locks the backend so only your site can call it.

---

## PART 6 — Test Everything

1. Open your live Netlify URL.
2. Click Welcome → enter a name → try "Complete Today's Support" — it should open your real GPLinks link and, after completing it, auto-detect and mark support complete.
3. Click Admin Login → enter **your own real Telegram numeric ID** (get it from @userinfobot) — since you're the channel creator, you should get owner access.
4. In the admin panel, upload your channel logo — it'll now show for every visitor.

---

## Notes / limits to know

- The backend's session store is in-memory — if Render restarts your service (happens occasionally on the free tier), any *in-progress* (not-yet-completed) support sessions are lost. Completed supporter data lives in the frontend's storage layer, not affected by backend restarts.
- For real production scale (thousands of supporters), swap the in-memory `Map` in `server.js` for a small database (SQLite/Postgres) — happy to help with that when you're ready.
- Keep `TELEGRAM_BOT_TOKEN` and `GPLINKS_API_KEY` secret — never put them in the frontend file, only in Render's environment variables.
